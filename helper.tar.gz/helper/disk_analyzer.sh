#!/bin/bash

# ==================================================
# Анализатор дискового пространства
# Версия 1.0
# GitHub: https://github.com/kion85
# ==================================================

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
NC='\033[0m' # No Color

# Конфигурация
LOG_DIR="$HOME/.disk_analyzer"
LOG_FILE="$LOG_DIR/disk.log"

# Создание директории для логов
mkdir -p "$LOG_DIR"

# Функция логирования
log() {
    echo -e "$(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "$LOG_FILE"
}

# Функция вывода заголовка
print_header() {
    clear
    echo -e "${BLUE}==================================================${NC}"
    echo -e "${CYAN}        Анализатор дискового пространства${NC}"
    echo -e "${CYAN}               Версия 1.0${NC}"
    echo -e "${BLUE}==================================================${NC}"
    echo -e "${MAGENTA}  Рекомендуем канал по ремонту техники:${NC}"
    echo -e "${YELLOW}      https://www.youtube.com/@notebook31${NC}"
    echo -e "${BLUE}==================================================${NC}"
    echo ""
}

# Функция анализа использования диска
disk_usage() {
    print_header
    echo -e "${CYAN}=== ИСПОЛЬЗОВАНИЕ ДИСКОВОГО ПРОСТРАНСТВА ===${NC}"
    
    echo -e "${GREEN}Общая информация:${NC}"
    df -h
    
    echo -e "\n${GREEN}Детальная информация:${NC}"
    df -i
    
    echo -e "\n${GREEN}Крупные разделы:${NC}"
    df -h | grep -E '(/[^/]*$|/$)'
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция поиска больших файлов
find_large_files() {
    print_header
    echo -e "${CYAN}=== ПОИСК БОЛЬШИХ ФАЙЛОВ ===${NC}"
    
    echo -e "${YELLOW}Введите путь для поиска (по умолчанию: /):${NC}"
    read -r search_path
    
    if [[ -z "$search_path" ]]; then
        search_path="/"
    fi
    
    if [[ ! -d "$search_path" ]]; then
        echo -e "${RED}Директория не существует!${NC}"
        read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
        return
    fi
    
    echo -e "${YELLOW}Введите лимит размера (например: 100M, 1G):${NC}"
    read -r size_limit
    
    if [[ -z "$size_limit" ]]; then
        size_limit="100M"
    fi
    
    echo -e "${GREEN}Поиск файлов больше $size_limit в $search_path...${NC}"
    
    find "$search_path" -type f -size "+$size_limit" -exec ls -lh {} \; 2>/dev/null | \
    sort -k5hr | head -20
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция анализа использования по директориям
analyze_directories() {
    print_header
    echo -e "${CYAN}=== АНАЛИЗ ИСПОЛЬЗОВАНИЯ ПО ДИРЕКТОРИЯМ ===${NC}"
    
    echo -e "${YELLOW}Введите путь для анализа (по умолчанию: $HOME):${NC}"
    read -r analyze_path
    
    if [[ -z "$analyze_path" ]]; then
        analyze_path="$HOME"
    fi
    
    if [[ ! -d "$analyze_path" ]]; then
        echo -e "${RED}Директория не существует!${NC}"
        read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
        return
    fi
    
    echo -e "${GREEN}Анализ использования в $analyze_path...${NC}"
    
    if command -v ncdu >/dev/null 2>&1; then
        echo -e "${GREEN}Запуск ncdu...${NC}"
        sudo ncdu "$analyze_path"
    else
        echo -e "${YELLOW}Утилита ncdu не установлена. Использую du...${NC}"
        echo "Установите: sudo apt install ncdu"
        echo ""
        sudo du -h "$analyze_path" | sort -rh | head -20
    fi
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция очистки временных файлов
clean_temporary_files() {
    print_header
    echo -e "${CYAN}=== ОЧИСТКА ВРЕМЕННЫХ ФАЙЛОВ ===${NC}"
    
    echo -e "${RED}ВНИМАНИЕ: Эта операция удалит временные файлы!${NC}"
    echo -e "${YELLOW}Вы уверены, что хотите продолжить? (y/n):${NC}"
    read -r confirmation
    
    if [[ "$confirmation" != "y" && "$confirmation" != "Y" ]]; then
        echo -e "${YELLOW}Очистка отменена.${NC}"
        read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
        return
    fi
    
    echo -e "${GREEN}Очистка временных файлов...${NC}"
    
    # Очистка кэша пакетов
    if command -v apt >/dev/null 2>&1; then
        sudo apt clean
        sudo apt autoremove -y
    fi
    
    # Очистка временных файлов
    sudo rm -rf /tmp/*
    sudo rm -rf /var/tmp/*
    
    # Очистка кэша пользователя
    rm -rf ~/.cache/*
    
    # Очистка журналов (старые)
    sudo find /var/log -type f -name "*.log.*" -mtime +7 -delete
    sudo find /var/log -type f -name "*.gz" -delete
    
    echo -e "${GREEN}Очистка завершена!${NC}"
    
    # Показываем освобожденное место
    echo -e "\n${GREEN}Освобожденное место:${NC}"
    df -h /
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция проверки SMART статуса
check_smart_status() {
    print_header
    echo -e "${CYAN}=== ПРОВЕРКА SMART СТАТУСА ДИСКОВ ===${NC}"
    
    if command -v smartctl >/dev/null 2>&1; then
        echo -e "${GREEN}Поиск дисков...${NC}"
        
        # Поиск дисков
        disks=$(lsblk -d -o NAME | grep -E '^(sd|nvme|hd)')
        
        for disk in $disks; do
            echo -e "\n${GREEN}Проверка диска /dev/$disk:${NC}"
            sudo smartctl -H /dev/$disk | grep -E "(SMART|test|FAILED)"
            sudo smartctl -A /dev/$disk | grep -E "(Temperature|Reallocated|Pending|Uncorrectable)" | head -5
        done
    else
        echo -e "${RED}Утилита smartctl не найдена!${NC}"
        echo "Установите: sudo apt install smartmontools"
    fi
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция мониторинга дисков в реальном времени
disk_monitor() {
    print_header
    echo -e "${CYAN}=== МОНИТОРИНГ ДИСКОВ В РЕАЛЬНОМ ВРЕМЕНИ ===${NC}"
    
    echo -e "${GREEN}Мониторинг дисковой активности...${NC}"
    echo -e "${YELLOW}Нажмите Ctrl+C для остановки${NC}"
    
    if command -v iotop >/dev/null 2>&1; then
        sudo iotop
    elif command -v iostat >/dev/null 2>&1; then
        watch -n 1 iostat -dx
    else
        echo -e "${RED}Утилиты iotop и iostat не найдены!${NC}"
        echo "Установите: sudo apt install iotop sysstat"
        echo ""
        watch -n 1 'df -h; echo ""; lsblk'
    fi
}

# Главное меню
main_menu() {
    while true; do
        print_header
        
        echo -e "${CYAN}=== ГЛАВНОЕ МЕНЮ ===${NC}"
        echo "1. Использование дискового пространства"
        echo "2. Поиск больших файлов"
        echo "3. Анализ по директориям"
        echo "4. Очистка временных файлов"
        echo "5. Проверка SMART статуса"
        echo "6. Мониторинг дисков в реальном времени"
        echo "7. Рекомендуемый YouTube канал"
        echo "0. Выход"
        
        echo -e "\n${YELLOW}Выберите опцию:${NC}"
        read -r option
        
        case $option in
            1) disk_usage ;;
            2) find_large_files ;;
            3) analyze_directories ;;
            4) clean_temporary_files ;;
            5) check_smart_status ;;
            6) disk_monitor ;;
            7)
                xdg-open "https://www.youtube.com/@notebook31" 2>/dev/null || \
                echo -e "${YELLOW}Откройте в браузере: https://www.youtube.com/@notebook31${NC}"
                read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
                ;;
            0)
                echo -e "${GREEN}Завершение работы...${NC}"
                echo -e "${YELLOW}Не забудьте посетить канал: https://www.youtube.com/@notebook31${NC}"
                exit 0
                ;;
            *)
                echo -e "${RED}Неверная опция.${NC}"
                sleep 1
                ;;
        esac
    done
}

# Инициализация
mkdir -p "$LOG_DIR"
log "Запуск анализатора дисков"

# Запуск главного меню
main_menu