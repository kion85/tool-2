#!/bin/bash

# ==================================================
# Проверка безопасности системы
# Версия 1.0
# GitHub: https://github.com/kion85
# ==================================================

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
NC='\033[0m' # No Color

# Конфигурация
LOG_DIR="$HOME/.security_check"
LOG_FILE="$LOG_DIR/security.log"

# Создание директории для логов
mkdir -p "$LOG_DIR"

# Функция логирования
log() {
    echo -e "$(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "$LOG_FILE"
}

# Функция вывода заголовка
print_header() {
    clear
    echo -e "${BLUE}==================================================${NC}"
    echo -e "${CYAN}        Проверка безопасности системы${NC}"
    echo -e "${CYAN}               Версия 1.0${NC}"
    echo -e "${BLUE}==================================================${NC}"
    echo -e "${MAGENTA}  Рекомендуем канал по ремонту техники:${NC}"
    echo -e "${YELLOW}      https://www.youtube.com/@notebook31${NC}"
    echo -e "${BLUE}==================================================${NC}"
    echo ""
}

# Функция проверки обновлений безопасности
check_security_updates() {
    print_header
    echo -e "${CYAN}=== ПРОВЕРКА ОБНОВЛЕНИЙ БЕЗОПАСНОСТИ ===${NC}"
    
    if command -v apt >/dev/null 2>&1; then
        echo -e "${GREEN}Проверка обновлений безопасности...${NC}"
        sudo apt update
        sudo apt upgrade --dry-run | grep -i security
        
        echo -e "\n${GREEN}Список обновлений безопасности:${NC}"
        sudo apt list --upgradable | grep -i security
    else
        echo -e "${RED}Система управления пакетами apt не найдена!${NC}"
    fi
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция проверки открытых портов
check_open_ports() {
    print_header
    echo -e "${CYAN}=== ПРОВЕРКА ОТКРЫТЫХ ПОРТОВ ===${NC}"
    
    echo -e "${GREEN}Слушающие порты:${NC}"
    sudo netstat -tulpn
    
    echo -e "\n${GREEN}Активные соединения:${NC}"
    sudo netstat -tupn
    
    echo -e "\n${GREEN}Проверка с помощью ss:${NC}"
    sudo ss -tulpn
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция проверки настроек firewall
check_firewall() {
    print_header
    echo -e "${CYAN}=== ПРОВЕРКА FIREWALL ===${NC}"
    
    if command -v ufw >/dev/null 2>&1; then
        echo -e "${GREEN}Статус UFW:${NC}"
        sudo ufw status verbose
    else
        echo -e "${YELLOW}UFW не установлен.${NC}"
    fi
    
    if command -v iptables >/dev/null 2>&1; then
        echo -e "\n${GREEN}Правила iptables:${NC}"
        sudo iptables -L -n -v
    fi
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция проверки пользователей и прав
check_users_permissions() {
    print_header
    echo -e "${CYAN}=== ПРОВЕРКА ПОЛЬЗОВАТЕЛЕЙ И ПРАВ ===${NC}"
    
    echo -e "${GREEN}Пользователи с оболочкой:${NC}"
    grep -E ":/bin/(bash|sh|zsh|fish)" /etc/passwd
    
    echo -e "\n${GREEN}Пользователи с правами sudo:${NC}"
    grep -Po '^sudo.+:\K.*$' /etc/group | tr ',' '\n'
    
    echo -e "\n${GREEN}Файлы с SUID битом:${NC}"
    find / -type f -perm -4000 -exec ls -la {} \; 2>/dev/null | head -10
    
    echo -e "\n${GREEN}Файлы с SGID битом:${NC}"
    find / -type f -perm -2000 -exec ls -la {} \; 2>/dev/null | head -10
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция проверки SSH безопасности
check_ssh_security() {
    print_header
    echo -e "${CYAN}=== ПРОВЕРКА SSH БЕЗОПАСНОСТИ ===${NC}"
    
    if [[ -f /etc/ssh/sshd_config ]]; then
        echo -e "${GREEN}Настройки SSH:${NC}"
        grep -E "(PermitRootLogin|PasswordAuthentication|Port|Protocol)" /etc/ssh/sshd_config
        
        echo -e "\n${GREEN}Активные SSH сессии:${NC}"
        who
        
        echo -e "\n${GREEN}Последние SSH логины:${NC}"
        last | head -10
    else
        echo -e "${YELLOW}SSH сервер не установлен.${NC}"
    fi
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция проверки процессов и сервисов
check_processes_services() {
    print_header
    echo -e "${CYAN}=== ПРОВЕРКА ПРОЦЕССОВ И СЕРВИСОВ ===${NC}"
    
    echo -e "${GREEN}Запущенные сервисы:${NC}"
    if command -v systemctl >/dev/null 2>&1; then
        systemctl list-units --type=service --state=running | head -10
    else
        service --status-all | grep "+" | head -10
    fi
    
    echo -e "\n${GREEN}Сетевые процессы:${NC}"
    sudo lsof -i -P -n | head -10
    
    echo -e "\n${GREEN}Процессы с сетевыми соединениями:${NC}"
    sudo netstat -tulpn | head -10
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция сканирования на вирусы
virus_scan() {
    print_header
    echo -e "${CYAN}=== СКАНИРОВАНИЕ НА ВИРУСЫ ===${NC}"
    
    if command -v clamscan >/dev/null 2>&1; then
        echo -e "${GREEN}Запуск ClamAV...${NC}"
        echo -e "${YELLOW}Это может занять некоторое время...${NC}"
        
        # Сканирование критических директорий
        sudo clamscan -r /etc /bin /sbin /usr/bin /usr/sbin --infected --remove=no
        
        echo -e "\n${GREEN}Проверка обновлений антивируса:${NC}"
        sudo freshclam
    else
        echo -e "${RED}ClamAV не установлен!${NC}"
        echo "Установите: sudo apt install clamav clamav-daemon"
    fi
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция создания отчета безопасности
create_security_report() {
    print_header
    echo -e "${CYAN}=== СОЗДАНИЕ ОТЧЕТА БЕЗОПАСНОСТИ ===${NC}"
    
    local report_file="$LOG_DIR/security_report_$(date +%Y%m%d_%H%M%S).txt"
    
    echo -e "${GREEN}Создание отчета безопасности...${NC}"
    
    {
        echo "=== ОТЧЕТ БЕЗОПАСНОСТИ СИСТЕМЫ ==="
        echo "Дата: $(date)"
        echo "Хост: $(hostname)"
        echo ""
        echo "=== ОБНОВЛЕНИЯ БЕЗОПАСНОСТИ ==="
        sudo apt list --upgradable 2>/dev/null | grep -i security
        echo ""
        echo "=== ОТКРЫТЫЕ ПОРТЫ ==="
        sudo netstat -tulpn
        echo ""
        echo "=== ПОЛЬЗОВАТЕЛИ ==="
        grep -E ":/bin/(bash|sh|zsh|fish)" /etc/passwd
        echo ""
        echo "=== SSH НАСТРОЙКИ ==="
        grep -E "(PermitRootLogin|PasswordAuthentication)" /etc/ssh/sshd_config 2>/dev/null
        echo ""
        echo "=== ЗАПУЩЕННЫЕ СЕРВИСЫ ==="
        systemctl list-units --type=service --state=running 2>/dev/null | head -15
    } > "$report_file"
    
    echo -e "${GREEN}Отчет сохранен: $report_file${NC}"
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Главное меню
main_menu() {
    while true; do
        print_header
        
        echo -e "${CYAN}=== ГЛАВНОЕ МЕНЮ ===${NC}"
        echo "1. Проверка обновлений безопасности"
        echo "2. Проверка открытых портов"
        echo "3. Проверка firewall"
        echo "4. Проверка пользователей и прав"
        echo "5. Проверка SSH безопасности"
        echo "6. Проверка процессов и сервисов"
        echo "7. Сканирование на вирусы"
        echo "8. Создать отчет безопасности"
        echo "9. Рекомендуемый YouTube канал"
        echo "0. Выход"
        
        echo -e "\n${YELLOW}Выберите опцию:${NC}"
        read -r option
        
        case $option in
            1) check_security_updates ;;
            2) check_open_ports ;;
            3) check_firewall ;;
            4) check_users_permissions ;;
            5) check_ssh_security ;;
            6) check_processes_services ;;
            7) virus_scan ;;
            8) create_security_report ;;
            9)
                xdg-open "https://www.youtube.com/@notebook31" 2>/dev/null || \
                echo -e "${YELLOW}Откройте в браузере: https://www.youtube.com/@notebook31${NC}"
                read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
                ;;
            0)
                echo -e "${GREEN}Завершение работы...${NC}"
                echo -e "${YELLOW}Не забудьте посетить канал: https://www.youtube.com/@notebook31${NC}"
                exit 0
                ;;
            *)
                echo -e "${RED}Неверная опция.${NC}"
                sleep 1
                ;;
        esac
    done
}

# Инициализация
mkdir -p "$LOG_DIR"
log "Запуск проверки безопасности"

# Запуск главного меню
main_menu