#!/bin/bash

# ==================================================
# Сетевые инструменты и диагностика
# Версия 1.0
# GitHub: https://github.com/kion85
# ==================================================

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
NC='\033[0m' # No Color

# Конфигурация
LOG_DIR="$HOME/.network_tools"
LOG_FILE="$LOG_DIR/network.log"

# Создание директории для логов
mkdir -p "$LOG_DIR"

# Функция логирования
log() {
    echo -e "$(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "$LOG_FILE"
}

# Функция вывода заголовка
print_header() {
    clear
    echo -e "${BLUE}==================================================${NC}"
    echo -e "${CYAN}        Сетевые инструменты и диагностика${NC}"
    echo -e "${CYAN}               Версия 1.0${NC}"
    echo -e "${BLUE}==================================================${NC}"
    echo -e "${MAGENTA}  Рекомендуем канал по ремонту техники:${NC}"
    echo -e "${YELLOW}      https://www.youtube.com/@notebook31${NC}"
    echo -e "${BLUE}==================================================${NC}"
    echo ""
}

# Функция проверки подключения к интернету
check_internet() {
    print_header
    echo -e "${CYAN}=== ПРОВЕРКА ПОДКЛЮЧЕНИЯ К ИНТЕРНЕТУ ===${NC}"
    
    echo -e "${GREEN}Проверка соединения...${NC}"
    
    if ping -c 3 8.8.8.8 >/dev/null 2>&1; then
        echo -e "${GREEN}✓ Соединение с интернетом активно${NC}"
    else
        echo -e "${RED}✗ Нет соединения с интернетом${NC}"
    fi
    
    if ping -c 3 google.com >/dev/null 2>&1; then
        echo -e "${GREEN}✓ DNS работает корректно${NC}"
    else
        echo -e "${RED}✗ Проблемы с DNS${NC}"
    fi
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция информации о сетевых интерфейсах
network_info() {
    print_header
    echo -e "${CYAN}=== ИНФОРМАЦИЯ О СЕТЕВЫХ ИНТЕРФЕЙСАХ ===${NC}"
    
    echo -e "${GREEN}Сетевые интерфейсы:${NC}"
    ip -c addr show
    
    echo -e "\n${GREEN}Таблица маршрутизации:${NC}"
    ip -c route show
    
    echo -e "\n${GREEN}DNS серверы:${NC}"
    cat /etc/resolv.conf 2>/dev/null | grep -v "^#" | grep -v "^$"
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция сканирования портов
port_scan() {
    print_header
    echo -e "${CYAN}=== СКАНИРОВАНИЕ ПОРТОВ ===${NC}"
    
    echo -e "${YELLOW}Введите IP адрес или домен для сканирования:${NC}"
    read -r target
    
    if [[ -z "$target" ]]; then
        target="127.0.0.1"
    fi
    
    echo -e "${GREEN}Сканирование常见 портов на $target...${NC}"
    
    # common ports to scan
    ports=(21 22 23 25 53 80 110 135 139 143 443 445 993 995 1433 3306 3389 5432 5900 8080)
    
    for port in "${ports[@]}"; do
        (echo >/dev/tcp/$target/$port) >/dev/null 2>&1
        if [ $? -eq 0 ]; then
            echo -e "${GREEN}Порт $port: OPEN${NC}"
        else
            echo -e "${RED}Порт $port: CLOSED${NC}"
        fi
    done
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция traceroute
trace_route() {
    print_header
    echo -e "${CYAN}=== TRACEROUTE ===${NC}"
    
    echo -e "${YELLOW}Введите IP адрес или домен для трассировки:${NC}"
    read -r target
    
    if [[ -z "$target" ]]; then
        target="8.8.8.8"
    fi
    
    echo -e "${GREEN}Трассировка маршрута к $target...${NC}"
    
    if command -v traceroute >/dev/null 2>&1; then
        traceroute -w 1 -m 15 $target
    elif command -v tracepath >/dev/null 2>&1; then
        tracepath $target
    else
        echo -e "${RED}Утилиты traceroute и tracepath не найдены!${NC}"
        echo "Установите: sudo apt install traceroute"
    fi
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция whois
whois_lookup() {
    print_header
    echo -e "${CYAN}=== WHOIS ПРОВЕРКА ===${NC}"
    
    echo -e "${YELLOW}Введите домен или IP адрес:${NC}"
    read -r target
    
    if [[ -z "$target" ]]; then
        echo -e "${RED}Не указана цель!${NC}"
        read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
        return
    fi
    
    if command -v whois >/dev/null 2>&1; then
        echo -e "${GREEN}WHOIS информация для $target:${NC}"
        whois $target | head -20
    else
        echo -e "${RED}Утилита whois не найдена!${NC}"
        echo "Установите: sudo apt install whois"
    fi
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция проверки скорости сети
speed_test() {
    print_header
    echo -e "${CYAN}=== ТЕСТ СКОРОСТИ СЕТИ ===${NC}"
    
    echo -e "${GREEN}Тестирование скорости сети...${NC}"
    
    if command -v speedtest-cli >/dev/null 2>&1; then
        speedtest-cli --simple
    else
        echo -e "${YELLOW}Утилита speedtest-cli не установлена.${NC}"
        echo "Установите: sudo apt install speedtest-cli"
        echo ""
        echo -e "${GREEN}Базовый тест скорости:${NC}"
        
        # Создаем тестовый файл и замеряем время
        echo -e "Скачивание тестового файла..."
        time wget -O /dev/null http://speedtest.ftp.otenet.gr/files/test10Mb.db 2>&1 | grep -oP '([0-9.]+ [KM]B/s)'
    fi
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция мониторинга сетевого трафика
network_traffic() {
    print_header
    echo -e "${CYAN}=== МОНИТОРИНГ СЕТЕВОГО ТРАФИКА ===${NC}"
    
    echo -e "${GREEN}Текущие сетевые соединения:${NC}"
    echo -e "${YELLOW}Нажмите Ctrl+C для остановки${NC}"
    
    if command -v iftop >/dev/null 2>&1; then
        sudo iftop
    elif command -v nethogs >/dev/null 2>&1; then
        sudo nethogs
    else
        echo -e "${RED}Утилиты iftop и nethogs не найдены!${NC}"
        echo "Установите: sudo apt install iftop nethogs"
        echo ""
        echo -e "${GREEN}Альтернатива: watch netstat${NC}"
        watch -n 1 "netstat -tupan | grep -E '(ESTABLISHED|LISTEN)'"
    fi
}

# Главное меню
main_menu() {
    while true; do
        print_header
        
        echo -e "${CYAN}=== ГЛАВНОЕ МЕНЮ ===${NC}"
        echo "1. Проверка подключения к интернету"
        echo "2. Информация о сетевых интерфейсах"
        echo "3. Сканирование портов"
        echo "4. Traceroute"
        echo "5. WHOIS проверка"
        echo "6. Тест скорости сети"
        echo "7. Мониторинг сетевого трафика"
        echo "8. Рекомендуемый YouTube канал"
        echo "0. Выход"
        
        echo -e "\n${YELLOW}Выберите опцию:${NC}"
        read -r option
        
        case $option in
            1) check_internet ;;
            2) network_info ;;
            3) port_scan ;;
            4) trace_route ;;
            5) whois_lookup ;;
            6) speed_test ;;
            7) network_traffic ;;
            8)
                xdg-open "https://www.youtube.com/@notebook31" 2>/dev/null || \
                echo -e "${YELLOW}Откройте в браузере: https://www.youtube.com/@notebook31${NC}"
                read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
                ;;
            0)
                echo -e "${GREEN}Завершение работы...${NC}"
                echo -e "${YELLOW}Не забудьте посетить канал: https://www.youtube.com/@notebook31${NC}"
                exit 0
                ;;
            *)
                echo -e "${RED}Неверная опция.${NC}"
                sleep 1
                ;;
        esac
    done
}

# Инициализация
mkdir -p "$LOG_DIR"
log "Запуск сетевых инструментов"

# Запуск главного меню
main_menu