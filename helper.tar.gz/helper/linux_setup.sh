#!/bin/bash

# ==================================================
# Универсальная утилита настройки Linux
# Версия 2.1
# GitHub: https://github.com/kion85
# ==================================================

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
NC='\033[0m' # No Color

# Конфигурация
LOG_FILE="/var/log/linux_setup.log"
BACKUP_DIR="$HOME/linux_setup_backup"
CONFIG_DIR="$HOME/.config/linux_setup"

# Создание необходимых директорий
mkdir -p "$BACKUP_DIR" "$CONFIG_DIR"

# Функция логирования
log() {
    echo -e "$(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "$LOG_FILE"
}

# Функция вывода заголовка
print_header() {
    clear
    echo -e "${BLUE}==================================================${NC}"
    echo -e "${CYAN}         Универсальная утилита настройки Linux${NC}"
    echo -e "${CYAN}                   Версия 2.1${NC}"
    echo -e "${BLUE}==================================================${NC}"
    echo -e "${MAGENTA}  Рекомендуем канал по ремонту техники:${NC}"
    echo -e "${YELLOW}      https://www.youtube.com/@notebook31${NC}"
    echo -e "${BLUE}==================================================${NC}"
    echo ""
}

# Функция проверки прав администратора
check_root() {
    if [[ $EUID -eq 0 ]]; then
        echo -e "${RED}Предупреждение: Не рекомендуется запускать этот скрипт от root.${NC}"
        echo -e "${YELLOW}Некоторые функции могут потребовать прав суперпользователя, но это будет запрашиваться отдельно.${NC}"
        sleep 2
    fi
}

# Функция определения дистрибутива
detect_distro() {
    if [[ -f /etc/os-release ]]; then
        . /etc/os-release
        DISTRO=$ID
        DISTRO_NAME=$NAME
        DISTRO_VERSION=$VERSION_ID
    else
        echo -e "${RED}Не удалось определить дистрибутив!${NC}"
        exit 1
    fi
}

# Функция определения менеджера пакетов
detect_package_manager() {
    case $DISTRO in
        ubuntu|debian|linuxmint)
            PACKAGE_MANAGER="apt"
            INSTALL_CMD="sudo apt install -y"
            UPDATE_CMD="sudo apt update"
            UPGRADE_CMD="sudo apt upgrade -y"
            ;;
        fedora|rhel|centos)
            PACKAGE_MANAGER="dnf"
            INSTALL_CMD="sudo dnf install -y"
            UPDATE_CMD="sudo dnf update -y"
            UPGRADE_CMD="sudo dnf upgrade -y"
            ;;
        arch|manjaro)
            PACKAGE_MANAGER="pacman"
            INSTALL_CMD="sudo pacman -S --noconfirm"
            UPDATE_CMD="sudo pacman -Sy"
            UPGRADE_CMD="sudo pacman -Syu --noconfirm"
            ;;
        opensuse*)
            PACKAGE_MANAGER="zypper"
            INSTALL_CMD="sudo zypper install -y"
            UPDATE_CMD="sudo zypper refresh"
            UPGRADE_CMD="sudo zypper update -y"
            ;;
        *)
            echo -e "${RED}Неизвестный дистрибутив!${NC}"
            exit 1
            ;;
    esac
}

# Функция установки пакетов
install_packages() {
    local packages=$1
    echo -e "${CYAN}Установка пакетов: $packages${NC}"
    $INSTALL_CMD $packages
}

# Функция обновления системы
update_system() {
    echo -e "${CYAN}Обновление системы...${NC}"
    $UPDATE_CMD
    $UPGRADE_CMD
    log "Система обновлена"
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция установки окружений и менеджеров окон
install_de_wm() {
    print_header
    echo -e "${CYAN}=== УСТАНОВКА ОКРУЖЕНИЙ И МЕНЕДЖЕРОВ ОКОН ===${NC}"
    
    echo "Доступные варианты:"
    echo "1. GNOME"
    echo "2. KDE Plasma"
    echo "3. XFCE"
    echo "4. LXQt"
    echo "5. Cinnamon"
    echo "6. MATE"
    echo "7. i3 WM"
    echo "8. Openbox"
    echo "9. Awesome WM"
    echo "10. Sway (Wayland)"
    echo "0. Назад"
    
    echo -e "\n${YELLOW}Выберите вариант:${NC}"
    read -r choice
    
    case $choice in
        1)
            echo -e "${GREEN}Установка GNOME...${NC}"
            install_packages "gnome gnome-extra"
            ;;
        2)
            echo -e "${GREEN}Установка KDE Plasma...${NC}"
            install_packages "kde-plasma-desktop"
            ;;
        3)
            echo -e "${GREEN}Установка XFCE...${NC}"
            install_packages "xfce4 xfce4-goodies"
            ;;
        4)
            echo -e "${GREEN}Установка LXQt...${NC}"
            install_packages "lxqt"
            ;;
        5)
            echo -e "${GREEN}Установка Cinnamon...${NC}"
            install_packages "cinnamon"
            ;;
        6)
            echo -e "${GREEN}Установка MATE...${NC}"
            install_packages "mate mate-extra"
            ;;
        7)
            echo -e "${GREEN}Установка i3 WM...${NC}"
            install_packages "i3 i3status i3lock dmenu"
            ;;
        8)
            echo -e "${GREEN}Установка Openbox...${NC}"
            install_packages "openbox obconf obmenu"
            ;;
        9)
            echo -e "${GREEN}Установка Awesome WM...${NC}"
            install_packages "awesome awesome-extra"
            ;;
        10)
            echo -e "${GREEN}Установка Sway...${NC}"
            install_packages "sway swaylock swayidle"
            ;;
        0)
            return
            ;;
        *)
            echo -e "${RED}Неверный выбор!${NC}"
            ;;
    esac
    
    echo -e "${GREEN}Установка завершена!${NC}"
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция настройки терминала
setup_terminal() {
    print_header
    echo -e "${CYAN}=== НАСТРОЙКА ТЕРМИНАЛА ===${NC}"
    
    echo "Доступные опции:"
    echo "1. Установить Zsh + Oh My Zsh"
    echo "2. Установить Fish shell"
    echo "3. Настроить Bash"
    echo "4. Установить дополнительные утилиты"
    echo "5. Настроить псевдонимы (aliases)"
    echo "0. Назад"
    
    echo -e "\n${YELLOW}Выберите вариант:${NC}"
    read -r choice
    
    case $choice in
        1)
            echo -e "${GREEN}Установка Zsh и Oh My Zsh...${NC}"
            install_packages "zsh git curl"
            sh -c "$(curl -fsSL https://raw.githubusercontent.com/ohmyzsh/ohmyzsh/master/tools/install.sh)" "" --unattended
            chsh -s $(which zsh)
            ;;
        2)
            echo -e "${GREEN}Установка Fish shell...${NC}"
            install_packages "fish"
            chsh -s $(which fish)
            ;;
        3)
            echo -e "${GREEN}Настройка Bash...${NC}"
            # Добавление кастомных настроек в .bashrc
            cat >> ~/.bashrc << EOF

# Кастомные настройки Bash
alias ll='ls -alF'
alias la='ls -A'
alias l='ls -CF'
alias update='sudo apt update && sudo apt upgrade'
alias ..='cd ..'
alias ...='cd ../..'
alias grep='grep --color=auto'
alias egrep='egrep --color=auto'
alias fgrep='fgrep --color=auto'
EOF
            ;;
        4)
            echo -e "${GREEN}Установка дополнительных утилит...${NC}"
            install_packages "htop neofetch tmux ranger bat exa fd-find fzf"
            ;;
        5)
            echo -e "${GREEN}Настройка псевдонимов...${NC}"
            # Создание файла с алиасами
            cat > ~/.bash_aliases << EOF
# Полезные псевдонимы
alias sysinfo='neofetch'
alias diskusage='df -h'
alias memusage='free -h'
alias cpuinfo='lscpu'
alias pscpu='ps auxf | sort -nr -k 3'
alias psmem='ps auxf | sort -nr -k 4'
alias weather='curl wttr.in'
alias myip='curl ifconfig.me'
alias ports='netstat -tulanp'
alias update='sudo apt update && sudo apt upgrade -y'
alias cleanup='sudo apt autoremove -y && sudo apt clean'
EOF
            ;;
        0)
            return
            ;;
        *)
            echo -e "${RED}Неверный выбор!${NC}"
            ;;
    esac
    
    echo -e "${GREEN}Настройка завершена!${NC}"
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция установки полезных утилит
install_utilities() {
    print_header
    echo -e "${CYAN}=== УСТАНОВКА ПОЛЕЗНЫХ УТИЛИТ ===${NC}"
    
    echo "Доступные категории:"
    echo "1. Системные утилиты"
    echo "2. Сетевые утилиты"
    echo "3. Мультимедиа"
    echo "4. Разработка"
    echo "5. Безопасность"
    echo "6. Все основные утилиты"
    echo "0. Назад"
    
    echo -e "\n${YELLOW}Выберите вариант:${NC}"
    read -r choice
    
    case $choice in
        1)
            echo -e "${GREEN}Установка системных утилит...${NC}"
            install_packages "htop glances screenfetch inxi lsb-release lsb-core"
            ;;
        2)
            echo -e "${GREEN}Установка сетевых утилит...${NC}"
            install_packages "nmap net-tools wireshark iperf3 curl wget whois"
            ;;
        3)
            echo -e "${GREEN}Установка мультимедиа утилит...${NC}"
            install_packages "vlc ffmpeg gimp audacity obs-studio"
            ;;
        4)
            echo -e "${GREEN}Установка утилит для разработки...${NC}"
            install_packages "git python3 python3-pip nodejs npm code"
            ;;
        5)
            echo -e "${GREEN}Установка утилит безопасности...${NC}"
            install_packages "fail2ban ufw clamav clamtk rkhunter"
            ;;
        6)
            echo -e "${GREEN}Установка всех основных утилит...${NC}"
            install_packages "htop glances nmap net-tools vlc ffmpeg git python3 python3-pip nodejs npm fail2ban ufw curl wget"
            ;;
        0)
            return
            ;;
        *)
            echo -e "${RED}Неверный выбор!${NC}"
            ;;
    esac
    
    echo -e "${GREEN}Установка завершена!${NC}"
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция резервного копирования конфигов
backup_configs() {
    print_header
    echo -e "${CYAN}=== РЕЗЕРВНОЕ КОПИРОВАНИЕ КОНФИГУРАЦИЙ ===${NC}"
    
    local backup_name="config_backup_$(date +%Y%m%d_%H%M%S).tar.gz"
    local config_dirs=(
        "$HOME/.config"
        "$HOME/.ssh"
        "$HOME/.bashrc"
        "$HOME/.zshrc"
        "$HOME/.profile"
        "$HOME/.vimrc"
        "$HOME/.tmux.conf"
    )
    
    echo -e "${YELLOW}Создание резервной копии конфигурационных файлов...${NC}"
    tar -czf "$BACKUP_DIR/$backup_name" "${config_dirs[@]}" 2>/dev/null
    
    if [[ $? -eq 0 ]]; then
        echo -e "${GREEN}Резервная копия создана: $BACKUP_DIR/$backup_name${NC}"
        log "Создана резервная копия конфигов: $backup_name"
    else
        echo -e "${RED}Ошибка при создании резервной копии!${NC}"
    fi
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция восстановления конфигов
restore_configs() {
    print_header
    echo -e "${CYAN}=== ВОССТАНОВЛЕНИЕ КОНФИГУРАЦИЙ ===${NC}"
    
    echo "Доступные резервные копии:"
    local backups=($(ls "$BACKUP_DIR"/*.tar.gz 2>/dev/null))
    
    if [[ ${#backups[@]} -eq 0 ]]; then
        echo -e "${YELLOW}Резервные копии не найдены!${NC}"
        read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
        return 1
    fi
    
    for i in "${!backups[@]}"; do
        echo "$((i+1)). ${backups[$i]##*/}"
    done
    
    echo -e "\n${YELLOW}Выберите backup для восстановления:${NC}"
    read -r choice
    
    if [[ $choice -ge 1 && $choice -le ${#backups[@]} ]]; then
        local selected_backup="${backups[$((choice-1))]}"
        echo -e "${GREEN}Восстановление из $selected_backup...${NC}"
        tar -xzf "$selected_backup" -C "$HOME"
        echo -e "${GREEN}Восстановление завершено!${NC}"
        log "Восстановлены конфиги из: $selected_backup"
    else
        echo -e "${RED}Неверный выбор!${NC}"
    fi
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция показа информации о системе
system_info() {
    print_header
    echo -e "${CYAN}=== ИНФОРМАЦИЯ О СИСТЕМЕ ===${NC}"
    
    echo -e "${GREEN}Дистрибутив:${NC} $DISTRO_NAME"
    echo -e "${GREEN}Версия:${NC} $DISTRO_VERSION"
    echo -e "${GREEN}Менеджер пакетов:${NC} $PACKAGE_MANAGER"
    echo -e "${GREEN}Имя хоста:${NC} $(hostname)"
    echo -e "${GREEN}Пользователь:${NC} $(whoami)"
    echo -e "${GREEN}Время работы:${NC} $(uptime -p)"
    
    echo -e "\n${GREEN}Процессор:${NC} $(grep -m1 "model name" /proc/cpuinfo | cut -d: -f2 | sed 's/^ *//')"
    echo -e "${GREEN}Ядер:${NC} $(nproc)"
    echo -e "${GREEN}Память:${NC} $(free -h | awk '/Mem:/ {print $3 "/" $2}')"
    echo -e "${GREEN}Диск:${NC} $(df -h / | awk 'NR==2 {print $3 "/" $2 " (" $5 ")"}')"
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция открытия YouTube канала
open_youtube_channel() {
    print_header
    echo -e "${CYAN}=== КАНАЛ NOTEBOOK31 ===${NC}"
    
    echo -e "${GREEN}Рекомендуем канал по ремонту техники:${NC}"
    echo -e "${YELLOW}https://www.youtube.com/@notebook31${NC}"
    echo ""
    echo -e "${GREEN}Полезные видео по теме:${NC}"
    echo "- Ремонт ноутбуков"
    echo "- Диагностика hardware"
    echo "- Замена компонентов"
    echo "- Обзоры техники"
    
    # Попытка открыть в браузере
    if command -v xdg-open >/dev/null 2>&1; then
        echo -e "\n${YELLOW}Открываю канал в браузере...${NC}"
        xdg-open "https://www.youtube.com/@notebook31"
    else
        echo -e "\n${YELLOW}Откройте в браузере: https://www.youtube.com/@notebook31${NC}"
    fi
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Главное меню
main_menu() {
    while true; do
        print_header
        echo -e "${GREEN}Текущий дистрибутив: ${YELLOW}$DISTRO_NAME${NC}"
        echo -e "${GREEN}Версия: ${YELLOW}$DISTRO_VERSION${NC}"
        echo ""
        
        echo -e "${CYAN}=== ГЛАВНОЕ МЕНЮ ===${NC}"
        echo "1.  Обновить систему"
        echo "2.  Установить DE/WM"
        echo "3.  Настроить терминал"
        echo "4.  Установить полезные утилиты"
        echo "5.  Резервное копирование конфигов"
        echo "6.  Восстановление конфигов"
        echo "7.  Информация о системе"
        echo "8.  Канал notebook31 (YouTube)"
        echo "0.  Выход"
        
        echo -e "\n${YELLOW}Выберите опцию:${NC}"
        read -r option
        
        case $option in
            1) update_system ;;
            2) install_de_wm ;;
            3) setup_terminal ;;
            4) install_utilities ;;
            5) backup_configs ;;
            6) restore_configs ;;
            7) system_info ;;
            8) open_youtube_channel ;;
            0)
                echo -e "${GREEN}Завершение работы...${NC}"
                echo -e "${YELLOW}Не забудьте посетить канал: https://www.youtube.com/@notebook31${NC}"
                echo -e "${BLUE}GitHub: https://github.com/kion85${NC}"
                exit 0
                ;;
            *)
                echo -e "${RED}Неверная опция.${NC}"
                sleep 1
                ;;
        esac
    done
}

# Инициализация
check_root
detect_distro
detect_package_manager

# Запись в лог
log "Запуск утилиты настройки Linux"
log "Дистрибутив: $DISTRO_NAME"
log "Версия: $DISTRO_VERSION"
log "Пользователь: $USER"

# Запуск главного меню
main_menu