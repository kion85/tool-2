#!/bin/bash

# ==================================================
# Детектор и селектор графических адаптеров
# Версия 1.2
# ==================================================

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Функция вывода заголовка
print_header() {
    clear
    echo -e "${BLUE}==================================================${NC}"
    echo -e "${CYAN}       Детектор и селектор графических адаптеров${NC}"
    echo -e "${CYAN}                 Версия 1.2${NC}"
    echo -e "${BLUE}==================================================${NC}"
    echo ""
}

# Функция определения всех видеокарт в системе
detect_gpus() {
    echo -e "${CYAN}=== ОБНАРУЖЕНИЕ ГРАФИЧЕСКИХ АДАПТЕРОВ ===${NC}"
    
    # Поиск всех GPU через lspci
    local gpu_list
    gpu_list=$(lspci | grep -i "vga\|3d\|display")
    
    if [[ -z "$gpu_list" ]]; then
        echo -e "${RED}Графические адаптеры не обнаружены!${NC}"
        return 1
    fi
    
    echo -e "${GREEN}Обнаруженные графические адаптеры:${NC}"
    echo "$gpu_list"
    
    # Определяем производителей
    local intel_gpus
    local amd_gpus
    local nvidia_gpus
    local other_gpus
    
    intel_gpus=$(echo "$gpu_list" | grep -i "intel")
    amd_gpus=$(echo "$gpu_list" | grep -i "amd\|ati")
    nvidia_gpus=$(echo "$gpu_list" | grep -i "nvidia")
    other_gpus=$(echo "$gpu_list" | grep -v -i "intel\|amd\|ati\|nvidia")
    
    # Счетчики
    local intel_count=0
    local amd_count=0
    local nvidia_count=0
    local other_count=0
    
    # Массивы для хранения ID устройств
    INTEL_GPUS=()
    AMD_GPUS=()
    NVIDIA_GPUS=()
    OTHER_GPUS=()
    
    # Обработка Intel
    if [[ -n "$intel_gpus" ]]; then
        intel_count=$(echo "$intel_gpus" | wc -l)
        echo -e "\n${BLUE}Intel графические адаптеры ($intel_count):${NC}"
        while IFS= read -r line; do
            if [[ -n "$line" ]]; then
                local device_id
                device_id=$(echo "$line" | awk '{print $1}')
                INTEL_GPUS+=("$device_id")
                echo "[${#INTEL_GPUS[@]}] $line"
            fi
        done <<< "$intel_gpus"
    fi
    
    # Обработка AMD
    if [[ -n "$amd_gpus" ]]; then
        amd_count=$(echo "$amd_gpus" | wc -l)
        echo -e "\n${GREEN}AMD графические адаптеры ($amd_count):${NC}"
        while IFS= read -r line; do
            if [[ -n "$line" ]]; then
                local device_id
                device_id=$(echo "$line" | awk '{print $1}')
                AMD_GPUS+=("$device_id")
                echo "[${#AMD_GPUS[@]}] $line"
            fi
        done <<< "$amd_gpus"
    fi
    
    # Обработка NVIDIA
    if [[ -n "$nvidia_gpus" ]]; then
        nvidia_count=$(echo "$nvidia_gpus" | wc -l)
        echo -e "\n${GREEN}NVIDIA графические адаптеры ($nvidia_count):${NC}"
        while IFS= read -r line; do
            if [[ -n "$line" ]]; then
                local device_id
                device_id=$(echo "$line" | awk '{print $1}')
                NVIDIA_GPUS+=("$device_id")
                echo "[${#NVIDIA_GPUS[@]}] $line"
            fi
        done <<< "$nvidia_gpus"
    fi
    
    # Обработка других производителей
    if [[ -n "$other_gpus" ]]; then
        other_count=$(echo "$other_gpus" | wc -l)
        echo -e "\n${YELLOW}Другие графические адаптеры ($other_count):${NC}"
        while IFS= read -r line; do
            if [[ -n "$line" ]]; then
                local device_id
                device_id=$(echo "$line" | awk '{print $1}')
                OTHER_GPUS+=("$device_id")
                echo "[${#OTHER_GPUS[@]}] $line"
            fi
        done <<< "$other_gpus"
    fi
    
    echo -e "\n${CYAN}Всего обнаружено графических адаптеров: $((intel_count + amd_count + nvidia_count + other_count))${NC}"
}

# Функция получения подробной информации о конкретном GPU
get_gpu_details() {
    local device_id=$1
    
    echo -e "\n${CYAN}Подробная информация об устройстве $device_id:${NC}"
    lspci -v -s "$device_id"
    
    # Дополнительная информация через lshw если доступно
    if command -v lshw &> /dev/null; then
        echo -e "\n${CYAN}Детальная информация (lshw):${NC}"
        lshw -c display | grep -A 10 -B 5 "$device_id" || true
    fi
}

# Функция рекомендации драйверов
recommend_drivers() {
    local vendor=$1
    
    echo -e "\n${CYAN}РЕКОМЕНДАЦИИ ПО ДРАЙВЕРАМ:${NC}"
    
    case $vendor in
        "intel")
            echo -e "${BLUE}Для Intel графики рекомендуется:${NC}"
            echo "1. Intel Open Source Driver (i915) - уже в ядре"
            echo "2. Intel Compute Runtime для OpenCL"
            echo "3. Intel Media Driver для аппаратного ускорения видео"
            echo ""
            echo "Установка:"
            echo "sudo apt install intel-opencl-icd intel-media-va-driver"
            ;;
        "amd")
            echo -e "${GREEN}Для AMD графики рекомендуется:${NC}"
            echo "1. AMDGPU Open Source Driver - уже в ядре"
            echo "2. AMDGPU PRO Driver (проприетарный, для профессионального использования)"
            echo "3. Mesa Vulkan Driver для современных игр"
            echo ""
            echo "Установка open-source драйверов:"
            echo "sudo apt install mesa-vulkan-drivers mesa-va-drivers"
            ;;
        "nvidia")
            echo -e "${GREEN}Для NVIDIA графики рекомендуется:${NC}"
            echo "1. NVIDIA Proprietary Driver (рекомендуется для игр и профессиональных приложений)"
            echo "2. Nouveau Open Source Driver (базовая функциональность)"
            echo ""
            echo "Установка проприетарных драйверов:"
            echo "sudo ubuntu-drivers autoinstall"
            echo "или"
            echo "sudo apt install nvidia-driver-XXX (где XXX - версия драйвера)"
            ;;
        *)
            echo -e "${YELLOW}Для неизвестного производителя:${NC}"
            echo "Попробуйте найти драйверы на сайте производителя"
            echo "или использовать стандартные драйверы ядра Linux."
            ;;
    esac
}

# Функция выбора основной видеокарты
select_primary_gpu() {
    echo -e "\n${CYAN}=== ВЫБОР ОСНОВНОГО ГРАФИЧЕСКОГО АДАПТЕРА ===${NC}"
    
    echo "Доступные варианты:"
    echo "1. Использовать интегрированную графику Intel (энергоэффективность)"
    echo "2. Использовать дискретную графику AMD (производительность)"
    echo "3. Использовать дискретную графику NVIDIA (игры/CUDA)"
    echo "4. Автоматический выбор (рекомендуется)"
    echo "5. Вернуться назад"
    
    echo -e "\n${YELLOW}Выберите опцию:${NC}"
    read -r choice
    
    case $choice in
        1)
            setup_intel_primary
            ;;
        2)
            setup_amd_primary
            ;;
        3)
            setup_nvidia_primary
            ;;
        4)
            auto_select_gpu
            ;;
        5)
            return
            ;;
        *)
            echo -e "${RED}Неверный выбор!${NC}"
            ;;
    esac
}

# Настройка Intel как основной
setup_intel_primary() {
    echo -e "${BLUE}Настройка Intel в качестве основной графики...${NC}"
    
    if [[ ${#INTEL_GPUS[@]} -eq 0 ]]; then
        echo -e "${RED}Intel графические адаптеры не обнаружены!${NC}"
        return 1
    fi
    
    # Здесь будут команды для настройки primus/bumblebee/optimus
    # или правки конфигов Xorg/Wayland
    
    echo -e "${GREEN}Настройка завершена. Перезагрузите систему для применения изменений.${NC}"
    echo -e "${YELLOW}Примечание: Для переключения между GPU может потребоваться установка:${NC}"
    echo "sudo apt install primus primus-vk nvidia-prime"
}

# Настройка AMD как основной
setup_amd_primary() {
    echo -e "${GREEN}Настройка AMD в качестве основной графики...${NC}"
    
    if [[ ${#AMD_GPUS[@]} -eq 0 ]]; then
        echo -e "${RED}AMD графические адаптеры не обнаружены!${NC}"
        return 1
    fi
    
    # Команды для настройки AMD как основной
    echo -e "${GREEN}Настройка завершена. Перезагрузите систему для применения изменений.${NC}"
}

# Настройка NVIDIA как основной
setup_nvidia_primary() {
    echo -e "${GREEN}Настройка NVIDIA в качестве основной графики...${NC}"
    
    if [[ ${#NVIDIA_GPUS[@]} -eq 0 ]]; then
        echo -e "${RED}NVIDIA графические адаптеры не обнаружены!${NC}"
        return 1
    fi
    
    # Проверяем, установлены ли драйверы NVIDIA
    if ! command -v nvidia-smi &> /dev/null; then
        echo -e "${YELLOW}Драйверы NVIDIA не обнаружены. Установите их сначала.${NC}"
        recommend_drivers "nvidia"
        return 1
    fi
    
    # Команды для настройки NVIDIA как основной
    echo -e "${GREEN}Настройка завершена. Перезагрузите систему для применения изменений.${NC}"
}

# Автоматический выбор видеокарты
auto_select_gpu() {
    echo -e "${CYAN}Автоматический выбор оптимальной конфигурации...${NC}"
    
    # Приоритет: дискретная NVIDIA → дискретная AMD → интегрированная Intel
    if [[ ${#NVIDIA_GPUS[@]} -gt 0 ]]; then
        echo -e "${GREEN}Выбрана дискретная графика NVIDIA для максимальной производительности.${NC}"
        setup_nvidia_primary
    elif [[ ${#AMD_GPUS[@]} -gt 0 ]]; then
        echo -e "${GREEN}Выбрана дискретная графика AMD для хорошей производительности.${NC}"
        setup_amd_primary
    elif [[ ${#INTEL_GPUS[@]} -gt 0 ]]; then
        echo -e "${BLUE}Выбрана интегрированная графика Intel для энергоэффективности.${NC}"
        setup_intel_primary
    else
        echo -e "${RED}Подходящие графические адаптеры не обнаружены!${NC}"
    fi
}

# Функция проверки текущей активной видеокарты
check_active_gpu() {
    echo -e "${CYAN}=== ТЕКУЩАЯ АКТИВНАЯ ВИДЕОКАРТА ===${NC}"
    
    # Проверяем через различные методы
    if command -v nvidia-smi &> /dev/null; then
        echo -e "${GREEN}NVIDIA GPU активна:${NC}"
        nvidia-smi --query-gpu=name,driver_version,temperature.gpu --format=csv,noheader
    fi
    
    if command -v glxinfo &> /dev/null; then
        echo -e "\n${GREEN}OpenGL рендерер:${NC}"
        glxinfo | grep "OpenGL renderer" | head -1
    fi
    
    if command -v vulkaninfo &> /dev/null; then
        echo -e "\n${GREEN}Vulkan устройства:${NC}"
        vulkaninfo --summary 2>/dev/null | grep "deviceName" | head -3 || true
    fi
    
    # Проверка через DRI_PRIME
    if [[ -n "$DRI_PRIME" ]]; then
        echo -e "\n${YELLOW}Используется DRI_PRIME=$DRI_PRIME для выбора GPU${NC}"
    fi
}

# Главное меню
main_menu() {
    while true; do
        print_header
        
        # Показываем текущую активную видеокарту
        check_active_gpu
        echo ""
        
        # Обнаруживаем все видеокарты
        detect_gpus
        
        echo -e "\n${CYAN}=== ОСНОВНОЕ МЕНЮ ===${NC}"
        echo "1.  Показать подробную информацию о конкретном адаптере"
        echo "2.  Выбрать основной графический адаптер"
        echo "3.  Рекомендации по драйверам"
        echo "4.  Проверить текущую активную видеокарту"
        echo "5.  Обновить информацию"
        echo "0.  Выход"
        
        echo -e "\n${YELLOW}Выберите опцию:${NC}"
        read -r option
        
        case $option in
            1)
                echo -e "\n${YELLOW}Введите ID устройства (например: 00:02.0):${NC}"
                read -r device_id
                get_gpu_details "$device_id"
                read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
                ;;
            2)
                select_primary_gpu
                read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
                ;;
            3)
                echo -e "\n${YELLOW}Для какого производителя? (intel/amd/nvidia):${NC}"
                read -r vendor
                recommend_drivers "$vendor"
                read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
                ;;
            4)
                check_active_gpu
                read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
                ;;
            5)
                # Просто обновим меню
                ;;
            0)
                echo -e "${GREEN}Завершение работы...${NC}"
                exit 0
                ;;
            *)
                echo -e "${RED}Неверная опция.${NC}"
                sleep 1
                ;;
        esac
    done
}

# Проверка прав администратора
if [[ $EUID -eq 0 ]]; then
    echo -e "${RED}Предупреждение: Не рекомендуется запускать этот скрипт от root.${NC}"
    echo -e "${YELLOW}Некоторые функции могут потребовать прав суперпользователя, но это будет запрашиваться отдельно.${NC}"
    sleep 2
fi

# Запуск
main_menu