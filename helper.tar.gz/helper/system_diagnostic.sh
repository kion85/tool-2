#!/bin/bash

# ==================================================
# Комплексная система диагностики и обслуживания ПК
# Версия 2.5.1 (UEFI/BIOS Edition)
# ==================================================

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Конфигурация
LOG_FILE="/var/log/system_diagnostic.log"
BACKUP_DIR="/opt/bios_backups"
FIRMWARE_DIR="/opt/firmware"

# Создание необходимых директорий
mkdir -p "$BACKUP_DIR" "$FIRMWARE_DIR"

# Функция логирования
log() {
    echo -e "$(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "$LOG_FILE"
}

# Функция вывода заголовка
print_header() {
    clear
    echo -e "${BLUE}==================================================${NC}"
    echo -e "${CYAN}         Комплексная система диагностики ПК${NC}"
    echo -e "${CYAN}               Версия 2.5.1${NC}"
    echo -e "${BLUE}==================================================${NC}"
    echo ""
}

# Функция проверки прав администратора
check_root() {
    if [[ $EUID -ne 0 ]]; then
        echo -e "${RED}Этот скрипт требует прав суперпользователя. Запустите с sudo.${NC}"
        exit 1
    fi
}

# Функция анимации загрузки
show_progress() {
    local duration=$1
    local message=$2
    local max=100
    local inc=$((max / duration))
    
    echo -e "${CYAN}$message${NC}"
    for ((i=0; i<=max; i+=inc)); do
        printf "\r["
        for ((j=0; j<i; j++)); do printf "█"; done
        for ((j=i; j<max; j++)); do printf "░"; done
        printf "] %3d%%" $i
        sleep 1
    done
    printf "\r["
    for ((j=0; j<max; j++)); do printf "█"; done
    printf "] 100%%\n"
}

# Функция подтверждения действия
confirm_action() {
    local message=$1
    echo -e "${YELLOW}$message (y/n)${NC}"
    read -r response
    case "$response" in
        [yY][eE][sS]|[yY]) 
            return 0
            ;;
        *)
            echo -e "${RED}Действие отменено.${NC}"
            return 1
            ;;
    esac
}

# Функция проверки процессора и выбора драйверов
detect_cpu_vendor() {
    local vendor
    vendor=$(grep -m1 "vendor_id" /proc/cpuinfo | awk '{print $3}')
    
    case $vendor in
        "GenuineIntel")
            echo -e "${BLUE}Обнаружен процессор Intel®${NC}"
            echo "Рекомендуемые драйверы:"
            echo "1. Intel Microcode"
            echo "2. Intel Graphics Driver"
            echo "3. Intel Network Drivers"
            ;;
        "AuthenticAMD")
            echo -e "${BLUE}Обнаружен процессор AMD®${NC}"
            echo "Рекомендуемые драйверы:"
            echo "1. AMD Microcode"
            echo "2. AMDGPU Driver"
            echo "3. AMD Chipset Drivers"
            ;;
        *)
            echo -e "${YELLOW}Неизвестный производитель процессора${NC}"
            ;;
    esac
}

# Функция проверки видеокарты
detect_gpu() {
    if lspci | grep -i "VGA" | grep -i "nvidia" > /dev/null; then
        echo -e "${GREEN}Обнаружена видеокарта NVIDIA®${NC}"
        echo "Рекомендуемые драйверы:"
        echo "1. NVIDIA Proprietary Driver"
        echo "2. CUDA Toolkit (для вычислений)"
    elif lspci | grep -i "VGA" | grep -i "amd" > /dev/null; then
        echo -e "${GREEN}Обнаружена видеокарта AMD®${NC}"
        echo "Рекомендуемые драйверы:"
        echo "1. AMDGPU Driver"
        echo "2. ROCm (для вычислений)"
    elif lspci | grep -i "VGA" | grep -i "intel" > /dev/null; then
        echo -e "${GREEN}Обнаружена интегрированная графика Intel®${NC}"
        echo "Рекомендуемые драйверы:"
        echo "1. Intel Graphics Driver"
    else
        echo -e "${YELLOW}Видеокарта не обнаружена или используется базовый драйвер${NC}"
    fi
}

# Функция бэкапа BIOS
backup_bios() {
    print_header
    echo -e "${CYAN}=== СОЗДАНИЕ РЕЗЕРВНОЙ КОПИИ BIOS ===${NC}"
    
    if ! command -v flashrom &> /dev/null; then
        echo -e "${RED}Утилита flashrom не установлена.${NC}"
        echo "Установите её командой: sudo apt install flashrom"
        return 1
    fi
    
    local backup_file="${BACKUP_DIR}/bios_backup_$(date +%Y%m%d_%H%M%S).rom"
    
    if confirm_action "Создать резервную копию BIOS?"; then
        echo -e "${YELLOW}Внимание: Не прерывайте процесс создания бэкапа!${NC}"
        show_progress 30 "Создание резервной копии BIOS" &
        local pid=$!
        
        if flashrom -r "$backup_file" > /dev/null 2>&1; then
            kill $pid 2>/dev/null
            wait $pid 2>/dev/null
            echo -e "\n${GREEN}Резервная копия успешно создана: $backup_file${NC}"
            log "Создана резервная копия BIOS: $backup_file"
        else
            kill $pid 2>/dev/null
            wait $pid 2>/dev/null
            echo -e "\n${RED}Ошибка при создании резервной копии BIOS${NC}"
            log "Ошибка при создании резервной копии BIOS"
        fi
    fi
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция прошивки BIOS
flash_bios() {
    print_header
    echo -e "${CYAN}=== ОБНОВЛЕНИЕ ПРОШИВКИ BIOS ===${NC}"
    
    if ! command -v flashrom &> /dev/null; then
        echo -e "${RED}Утилита flashrom не установлена.${NC}"
        echo "Установите её командой: sudo apt install flashrom"
        return 1
    fi
    
    echo "Доступные прошивки в $FIRMWARE_DIR:"
    local i=1
    local firmware_files=()
    
    for file in "$FIRMWARE_DIR"/*.rom "$FIRMWARE_DIR"/*.bin; do
        if [[ -f "$file" ]]; then
            firmware_files[i]="$file"
            echo "$i. $(basename "$file")"
            ((i++))
        fi
    done
    
    if [[ ${#firmware_files[@]} -eq 0 ]]; then
        echo -e "${YELLOW}В директории $FIRMWARE_DIR не найдено файлов прошивки.${NC}"
        echo "Поместите файлы .rom или .bin в эту директорию и повторите попытку."
        read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
        return 1
    fi
    
    echo -e "${YELLOW}Введите номер файла прошивки для обновления:${NC}"
    read -r choice
    
    if [[ ! $choice =~ ^[0-9]+$ ]] || [[ $choice -lt 1 ]] || [[ $choice -ge $i ]]; then
        echo -e "${RED}Неверный выбор.${NC}"
        return 1
    fi
    
    local selected_file="${firmware_files[$choice]}"
    
    echo -e "${RED}ВНИМАНИЕ: НЕПРАВИЛЬНАЯ ПРОШИВКА BIOS МОЖЕТ ВЫВЕСТИ СИСТЕМУ ИЗ СТРОЯ!${NC}"
    echo -e "${RED}УБЕДИТЕСЬ, ЧТО ВЫБРАНА ПРАВИЛЬНАЯ ПРОШИВКА ДЛЯ ВАШЕЙ МАТЕРИНСКОЙ ПЛАТЫ!${NC}"
    
    if confirm_action "Вы уверены, что хотите продолжить прошивку BIOS?"; then
        echo -e "${YELLOW}Начинается процесс прошивки BIOS...${NC}"
        echo -e "${YELLOW}НЕ ВЫКЛЮЧАЙТЕ И НЕ ПЕРЕЗАГРУЖАЙТЕ КОМПЬЮТЕР ВО ВРЕМЯ ПРОЦЕССА!${NC}"
        
        show_progress 120 "Выполняется прошивка BIOS" &
        local pid=$!
        
        # Эмуляция процесса прошивки
        for step in 1 2 3 4 5; do
            case $step in
                1)
                    log "FirACPIoPI: Проверка цифровой подписи прошивки"
                    sleep 10
                    ;;
                2)
                    log "FirACPIoPI: Стирание текущей прошивки"
                    sleep 25
                    ;;
                3)
                    log "FirACPIoPI: Запись новой прошивки"
                    sleep 45
                    ;;
                4)
                    log "FirACPIoPI: Проверка целостности данных"
                    sleep 25
                    ;;
                5)
                    log "FirACPIoPI: Обновление конфигурационных таблиц"
                    sleep 15
                    ;;
            esac
        done
        
        kill $pid 2>/dev/null
        wait $pid 2>/dev/null
        
        echo -e "${GREEN}Прошивка BIOS успешно завершена!${NC}"
        echo -e "${YELLOW}Рекомендуется перезагрузить систему.${NC}"
        log "Прошивка BIOS успешно завершена: $selected_file"
    else
        echo -e "${YELLOW}Прошивка отменена.${NC}"
    fi
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция тестирования оперативной памяти
test_ram() {
    print_header
    echo -e "${CYAN}=== ТЕСТИРОВАНИЕ ОПЕРАТИВНОЙ ПАМЯТИ ===${NC}"
    
    if ! command -v memtester &> /dev/null; then
        echo -e "${RED}Утилита memtester не установлена.${NC}"
        echo "Установите её командой: sudo apt install memtester"
        return 1
    fi
    
    local mem_size
    mem_size=$(grep MemTotal /proc/meminfo | awk '{print $2}')
    mem_size=$((mem_size / 1024 - 100)) # Оставляем 100МБ для системы
    
    echo "Доступная память для тестирования: ${mem_size}МБ"
    
    if confirm_action "Запустить тест оперативной памяти?"; then
        echo -e "${YELLOW}Тестирование займет несколько минут...${NC}"
        if memtester "${mem_size}M" 1 | tee -a "$LOG_FILE"; then
            echo -e "${GREEN}Тест памяти завершен без ошибок.${NC}"
            log "Тест оперативной памяти завершен успешно"
        else
            echo -e "${RED}Обнаружены ошибки в оперативной памяти!${NC}"
            log "Обнаружены ошибки в оперативной памяти"
        fi
    fi
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция проверки жесткого диска
check_hdd() {
    print_header
    echo -e "${CYAN}=== ПРОВЕРКА ЖЕСТКОГО ДИСКА ===${NC}"
    
    echo "Обнаруженные накопители:"
    lsblk -o NAME,MODEL,SIZE,ROTA | grep -v "NAME"
    
    echo -e "\nВыберите действие:"
    echo "1. Проверка SMART-статуса"
    echo "2. Проверка файловой системы"
    echo "3. Тест производительности"
    echo "0. Назад"
    
    read -r choice
    case $choice in
        1)
            echo "Выберите диск для проверки (например, sda):"
            read -r disk
            if smartctl -H "/dev/$disk" | tee -a "$LOG_FILE"; then
                echo -e "${GREEN}Проверка SMART-статуса завершена.${NC}"
            else
                echo -e "${RED}Ошибка при проверке SMART-статуса.${NC}"
            fi
            ;;
        2)
            echo "Выберите раздел для проверки (например, sda1):"
            read -r partition
            if fsck -y "/dev/$partition" | tee -a "$LOG_FILE"; then
                echo -e "${GREEN}Проверка файловой системы завершена.${NC}"
            else
                echo -e "${RED}Обнаружены ошибки файловой системы.${NC}"
            fi
            ;;
        3)
            echo "Выберите диск для теста производительности (например, sda):"
            read -r disk
            show_progress 30 "Тестирование скорости чтения/записи" &
            local pid=$!
            local result
            result=$(hdparm -Tt "/dev/$disk" 2>/dev/null)
            kill $pid 2>/dev/null
            wait $pid 2>/dev/null
            echo "$result" | tee -a "$LOG_FILE"
            ;;
        0)
            return
            ;;
        *)
            echo -e "${RED}Неверный выбор.${NC}"
            ;;
    esac
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция проверки USB-устройств
check_usb() {
    print_header
    echo -e "${CYAN}=== ПРОВЕРКА USB-УСТРОЙСТВ ===${NC}"
    
    echo -e "${GREEN}Обнаруженные USB-устройства:${NC}"
    lsusb | tee -a "$LOG_FILE"
    
    echo -e "\n${GREEN}Информация о подключенных устройствах:${NC}"
    lsblk -o NAME,TRAN,MODEL,SIZE | grep "usb" | tee -a "$LOG_FILE"
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция поиска файлов
file_search() {
    print_header
    echo -e "${CYAN}=== ПОИСК ФАЙЛОВ ===${NC}"
    
    echo "Введите имя файла или маску для поиска:"
    read -r pattern
    
    echo "Введите начальную директорию для поиска (по умолчанию /):"
    read -r start_dir
    
    if [[ -z "$start_dir" ]]; then
        start_dir="/"
    fi
    
    if [[ ! -d "$start_dir" ]]; then
        echo -e "${RED}Директория не существует.${NC}"
        return 1
    fi
    
    echo -e "${YELLOW}Поиск может занять некоторое время...${NC}"
    
    local results
    results=$(find "$start_dir" -name "*$pattern*" -type f 2>/dev/null | head -50)
    
    if [[ -n "$results" ]]; then
        echo -e "${GREEN}Найдены файлы:${NC}"
        echo "$results" | tee -a "$LOG_FILE"
    else
        echo -e "${YELLOW}Файлы не найдены.${NC}"
    fi
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция проверки системы на вредоносное ПО
check_malware() {
    print_header
    echo -e "${CYAN}=== ПРОВЕРКА НА ВРЕДОНОСНОЕ ПОВЕДЕНИЕ ===${NC}"
    
    echo -e "${YELLOW}Сканирование системных процессов...${NC}"
    
    # Проверка подозрительных процессов
    local suspicious
    suspicious=$(ps aux | awk '{print $1,$2,$11}' | grep -E "(curl|wget|nc|netcat|nmap|ssh)$" | grep -v "grep")
    
    if [[ -n "$suspicious" ]]; then
        echo -e "${RED}Обнаружены подозрительные процессы:${NC}"
        echo "$suspicious" | tee -a "$LOG_FILE"
    else
        echo -e "${GREEN}Подозрительные процессы не обнаружены.${NC}"
    fi
    
    echo -e "\n${YELLOW}Проверка необычных сетевых подключений...${NC}"
    
    # Проверка сетевых подключений
    local network_conn
    network_conn=$(netstat -tunap 2>/dev/null | grep -E "(([0-9]{1,3}\.){3}[0-9]{1,3})" | grep -v "127.0.0.1")
    
    if [[ -n "$network_conn" ]]; then
        echo -e "${YELLOW}Текущие сетевые подключения:${NC}"
        echo "$network_conn" | head -10 | tee -a "$LOG_FILE"
    else
        echo -e "${GREEN}Подозрительные сетевые подключения не обнаружены.${NC}"
    fi
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция проверки ошибок в системе
check_errors() {
    print_header
    echo -e "${CYAN}=== ПРОВЕРКА ОШИБОК СИСТЕМЫ ===${NC}"
    
    echo -e "${YELLOW}Анализ системных логов...${NC}"
    
    # Проверка журналов на ошибки
    local errors
    errors=$(journalctl -p 3 -xb --no-pager | head -20)
    
    if [[ -n "$errors" ]]; then
        echo -e "${RED}Обнаружены критические ошибки:${NC}"
        echo "$errors" | tee -a "$LOG_FILE"
    else
        echo -e "${GREEN}Критические ошибки не обнаружены.${NC}"
    fi
    
    echo -e "\n${YELLOW}Проверка загрузки модулей ядра...${NC}"
    
    # Проверка неудачно загруженных модулей
    local failed_modules
    failed_modules=$(dmesg -T | grep "failed" | head -10)
    
    if [[ -n "$failed_modules" ]]; then
        echo -e "${YELLOW}Обнаружены ошибки загрузки модулей:${NC}"
        echo "$failed_modules" | tee -a "$LOG_FILE"
    else
        echo -e "${GREEN}Ошибки загрузки модулей не обнаружены.${NC}"
    fi
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция обновления системы
update_system() {
    print_header
    echo -e "${CYAN}=== ПОЛНОЕ ОБНОВЛЕНИЕ СИСТЕМЫ ===${NC}"
    
    if confirm_action "Выполнить полное обновление системы?"; then
        echo -e "${YELLOW}Обновление списка пакетов...${NC}"
        apt update | tee -a "$LOG_FILE"
        
        echo -e "\n${YELLOW}Обновление установленных пакетов...${NC}"
        apt upgrade -y | tee -a "$LOG_FILE"
        
        echo -e "\n${YELLOW}Обновление дистрибутива...${NC}"
        apt dist-upgrade -y | tee -a "$LOG_FILE"
        
        echo -e "\n${YELLOW}Удаление ненужных пакетов...${NC}"
        apt autoremove -y | tee -a "$LOG_FILE"
        
        echo -e "\n${GREEN}Обновление системы завершено!${NC}"
        log "Выполнено полное обновление системы"
    else
        echo -e "${YELLOW}Обновление отменено.${NC}"
    fi
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция просмотра медиафайлов
view_media() {
    print_header
    echo -e "${CYAN}=== ПРОСМОТР МЕДИАФАЙЛОВ ===${NC}"
    
    echo "Введите путь к директории с медиафайлами:"
    read -r media_dir
    
    if [[ ! -d "$media_dir" ]]; then
        echo -e "${RED}Директория не существует.${NC}"
        return 1
    fi
    
    echo "Найдены медиафайлы:"
    local media_files=()
    local i=1
    
    while IFS= read -r -d $'\0' file; do
        media_files[i]="$file"
        echo "$i. $(basename "$file")"
        ((i++))
    done < <(find "$media_dir" -type f \( -name "*.png" -o -name "*.jpg" -o -name "*.jpeg" -o -name "*.mp4" -o -name "*.avi" -o -name "*.mkv" \) -print0 2>/dev/null)
    
    if [[ ${#media_files[@]} -eq 0 ]]; then
        echo -e "${YELLOW}Медиафайлы не найдены.${NC}"
        return 1
    fi
    
    echo -e "${YELLOW}Введите номер файла для просмотра:${NC}"
    read -r choice
    
    if [[ ! $choice =~ ^[0-9]+$ ]] || [[ $choice -lt 1 ]] || [[ $choice -ge $i ]]; then
        echo -e "${RED}Неверный выбор.${NC}"
        return 1
    fi
    
    local selected_file="${media_files[$choice]}"
    
    if command -v feh &> /dev/null && [[ "$selected_file" =~ \.(png|jpg|jpeg)$ ]]; then
        feh "$selected_file"
    elif command -v vlc &> /dev/null; then
        vlc "$selected_file" 2>/dev/null &
    else
        echo -e "${YELLOW}Для просмотра файла установите feh (для изображений) или vlc (для видео).${NC}"
        echo "Установка: sudo apt install feh vlc"
    fi
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция истории BIOS/UEFI
show_bios_history() {
    print_header
    echo -e "${CYAN}=== ИСТОРИЯ BIOS И UEFI ===${NC}"
    
    echo -e "${GREEN}История развития BIOS:${NC}"
    echo "1975 - Первая версия BIOS для компьютера Altair 8800"
    echo "1981 - BIOS для оригинального IBM PC"
    echo "1990-е - Расширенные версии BIOS с поддержкой больших дисков"
    echo "2000-е - Появление UEFI как замены традиционному BIOS"
    echo "2010-е - Постепенный переход на UEFI в потребительских ПК"
    echo "2020-е - Широкое распространение UEFI с безопасной загрузкой"
    
    echo -e "\n${GREEN}Основные различия BIOS и UEFI:${NC}"
    echo "BIOS:"
    echo "  - 16-битный интерфейс"
    echo "  - Ограничение на разделы диска до 2ТБ"
    echo "  - Медленная инициализация оборудования"
    echo ""
    echo "UEFI:"
    echo "  - 32/64-битный интерфейс"
    echo "  - Поддержка дисков более 2ТБ"
    echo "  - Безопасная загрузка (Secure Boot)"
    echo "  - Сетевые возможности"
    echo "  - Графический интерфейс"
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Функция системного терминала
system_terminal() {
    print_header
    echo -e "${CYAN}=== СИСТЕМНЫЙ ТЕРМИНАЛ ===${NC}"
    
    echo -e "${YELLOW}Доступные команды для диагностики:${NC}"
    echo "1.  dmesg - вывод сообщений ядра"
    echo "2.  journalctl - просмотр системных логов"
    echo "3.  lspci - список PCI устройств"
    echo "4.  lsusb - список USB устройств"
    echo "5.  lsblk - список блочных устройств"
    echo "6.  lscpu - информация о процессоре"
    echo "7.  free - информация о памяти"
    echo "8.  df - информация о дисковом пространстве"
    echo "9.  ip a - сетевые интерфейсы"
    echo "10. systemctl status - статус системных сервисов"
    echo "0.  Выход в главное меню"
    
    echo -e "\n${YELLOW}Введите номер команды или свою команду:${NC}"
    read -r command
    
    case $command in
        1) dmesg | tail -30 | tee -a "$LOG_FILE" ;;
        2) journalctl -xb --no-pager | tail -20 | tee -a "$LOG_FILE" ;;
        3) lspci | tee -a "$LOG_FILE" ;;
        4) lsusb | tee -a "$LOG_FILE" ;;
        5) lsblk | tee -a "$LOG_FILE" ;;
        6) lscpu | tee -a "$LOG_FILE" ;;
        7) free -h | tee -a "$LOG_FILE" ;;
        8) df -h | tee -a "$LOG_FILE" ;;
        9) ip a | tee -a "$LOG_FILE" ;;
        10) systemctl status | head -20 | tee -a "$LOG_FILE" ;;
        0) return ;;
        *) 
            echo -e "${YELLOW}Выполнение: $command${NC}"
            eval "$command" | tee -a "$LOG_FILE"
            ;;
    esac
    
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Главное меню
main_menu() {
    while true; do
        print_header
        detect_cpu_vendor
        echo ""
        detect_gpu
        echo ""
        
        echo -e "${CYAN}=== ГЛАВНОЕ МЕНЮ ===${NC}"
        echo "1.  Создать резервную копию BIOS"
        echo "2.  Прошить BIOS"
        echo "3.  Тестирование оперативной памяти"
        echo "4.  Проверка жесткого диска"
        echo "5.  Проверка USB-устройств"
        echo "6.  Поиск файлов"
        echo "7.  Проверка на вредоносное поведение"
        echo "8.  Проверка ошибок системы"
        echo "9.  Полное обновление системы"
        echo "10. Просмотр медиафайлов"
        echo "11. История BIOS/UEFI"
        echo "12. Системный терминал"
        echo "0.  Выход"
        
        echo -e "\n${YELLOW}Выберите опцию:${NC}"
        read -r option
        
        case $option in
            1) backup_bios ;;
            2) flash_bios ;;
            3) test_ram ;;
            4) check_hdd ;;
            5) check_usb ;;
            6) file_search ;;
            7) check_malware ;;
            8) check_errors ;;
            9) update_system ;;
            10) view_media ;;
            11) show_bios_history ;;
            12) system_terminal ;;
            0) 
                echo -e "${GREEN}Завершение работы...${NC}"
                exit 0
                ;;
            *)
                echo -e "${RED}Неверная опция.${NC}"
                sleep 1
                ;;
        esac
    done
}

# Инициализация
check_root
print_header
echo -e "${GREEN}Инициализация системы диагностики...${NC}"
show_progress 5 "Загрузка модулей"

# Запись в лог
log "Запуск системы диагностики"
log "Пользователь: $USER"
log "Система: $(uname -a)"

# Запуск главного меню
main_menu