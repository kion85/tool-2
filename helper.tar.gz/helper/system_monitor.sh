#!/bin/bash

# ==================================================
# Универсальная утилита мониторинга системы
# Версия 1.0
# GitHub: https://github.com/kion85
# ==================================================

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
NC='\033[0m' # No Color

# Конфигурация
LOG_DIR="$HOME/.system_monitor"
LOG_FILE="$LOG_DIR/monitor.log"

# Создание директории для логов
mkdir -p "$LOG_DIR"

# Функция логирования
log() {
    echo -e "$(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "$LOG_FILE"
}

# Функция вывода заголовка
print_header() {
    clear
    echo -e "${BLUE}==================================================${NC}"
    echo -e "${CYAN}        Утилита мониторинга системы${NC}"
    echo -e "${CYAN}               Версия 1.0${NC}"
    echo -e "${BLUE}==================================================${NC}"
    echo -e "${MAGENTA}  Рекомендуем канал по ремонту техники:${NC}"
    echo -e "${YELLOW}      https://www.youtube.com/@notebook31${NC}"
    echo -e "${BLUE}==================================================${NC}"
    echo ""
}

# Функция мониторинга ресурсов системы
monitor_resources() {
    print_header
    echo -e "${CYAN}=== МОНИТОРИНГ РЕСУРСОВ СИСТЕМЫ ===${NC}"
    
    while true; do
        clear
        echo -e "${GREEN}=== СИСТЕМНЫЕ РЕСУРСЫ ===${NC}"
        echo -e "CPU: $(top -bn1 | grep "Cpu(s)" | awk '{print $2}')% | Память: $(free -h | awk '/Mem:/ {print $3 "/" $2}')"
        echo -e "Загрузка: $(uptime | awk -F'load average:' '{print $2}')"
        
        echo -e "\n${GREEN}=== ДИСКОВОЕ ПРОСТРАНСТВО ===${NC}"
        df -h / | awk 'NR==2 {print "Корневой раздел: " $3 "/" $2 " (" $5 ")"}'
        df -h /home 2>/dev/null | awk 'NR==2 {print "Домашний каталог: " $3 "/" $2 " (" $5 ")"}'
        
        echo -e "\n${GREEN}=== СЕТЕВЫЕ СОЕДИНЕНИЯ ===${NC}"
        netstat -ant | awk '
            /ESTABLISHED/ {estab++}
            /TIME_WAIT/ {timewait++}
            /LISTEN/ {listen++}
            END {
                print "ESTABLISHED: " estab
                print "TIME_WAIT: " timewait  
                print "LISTEN: " listen
            }'
        
        echo -e "\n${YELLOW}Нажмите Ctrl+C для выхода в меню${NC}"
        sleep 2
    done
}

# Функция просмотра процессов
process_monitor() {
    print_header
    echo -e "${CYAN}=== МОНИТОРИНГ ПРОЦЕССОВ ===${NC}"
    
    echo "1. Все процессы"
    echo "2. Процессы потребляющие много CPU"
    echo "3. Процессы потребляющие много памяти"
    echo "4. Сетевые процессы"
    echo "0. Назад"
    
    read -r choice
    case $choice in
        1) 
            watch -n 1 "ps aux --sort=-%cpu | head -20"
            ;;
        2)
            watch -n 1 "ps aux --sort=-%cpu | head -10"
            ;;
        3)
            watch -n 1 "ps aux --sort=-%mem | head -10"
            ;;
        4)
            watch -n 1 "netstat -tulpna"
            ;;
        0)
            return
            ;;
        *)
            echo -e "${RED}Неверный выбор!${NC}"
            ;;
    esac
}

# Функция мониторинга температуры
temperature_monitor() {
    print_header
    echo -e "${CYAN}=== МОНИТОРИНГ ТЕМПЕРАТУРЫ ===${NC}"
    
    if command -v sensors >/dev/null 2>&1; then
        watch -n 2 sensors
    else
        echo -e "${YELLOW}Утилита 'sensors' не установлена.${NC}"
        echo "Установите пакет lm-sensors:"
        echo "sudo apt install lm-sensors"
        read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
    fi
}

# Функция просмотра логов
log_viewer() {
    print_header
    echo -e "${CYAN}=== ПРОСМОТР ЛОГОВ ===${NC}"
    
    echo "1. Системные логи (journalctl)"
    echo "2. Логи аутентификации"
    echo "3. Логи ядра"
    echo "4. Логи загрузки"
    echo "0. Назад"
    
    read -r choice
    case $choice in
        1)
            sudo journalctl -f
            ;;
        2)
            sudo tail -f /var/log/auth.log
            ;;
        3)
            sudo tail -f /var/log/kern.log
            ;;
        4)
            sudo journalctl -b -f
            ;;
        0)
            return
            ;;
        *)
            echo -e "${RED}Неверный выбор!${NC}"
            ;;
    esac
}

# Функция создания отчета
create_report() {
    print_header
    echo -e "${CYAN}=== СОЗДАНИЕ ОТЧЕТА О СИСТЕМЕ ===${NC}"
    
    local report_file="$LOG_DIR/system_report_$(date +%Y%m%d_%H%M%S).txt"
    
    echo -e "${GREEN}Создание отчета...${NC}"
    
    {
        echo "=== ОТЧЕТ О СИСТЕМЕ ==="
        echo "Дата: $(date)"
        echo "Хост: $(hostname)"
        echo "Пользователь: $(whoami)"
        echo ""
        echo "=== ИНФОРМАЦИЯ О СИСТЕМЕ ==="
        uname -a
        echo ""
        echo "=== ДИСТРИБУТИВ ==="
        cat /etc/os-release 2>/dev/null
        echo ""
        echo "=== ПРОЦЕССОР ==="
        lscpu
        echo ""
        echo "=== ПАМЯТЬ ==="
        free -h
        echo ""
        echo "=== ДИСКИ ==="
        df -h
        echo ""
        echo "=== СЕТЕВЫЕ ИНТЕРФЕЙСЫ ==="
        ip a
        echo ""
        echo "=== ЗАГРУЗКА СИСТЕМЫ ==="
        uptime
        echo ""
        echo "=== ПРОЦЕССЫ ==="
        ps aux --sort=-%cpu | head -10
        echo ""
        echo "=== СЕТЕВЫЕ СОЕДИНЕНИЯ ==="
        netstat -tulpn
    } > "$report_file"
    
    echo -e "${GREEN}Отчет сохранен: $report_file${NC}"
    read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
}

# Главное меню
main_menu() {
    while true; do
        print_header
        
        echo -e "${CYAN}=== ГЛАВНОЕ МЕНЮ ===${NC}"
        echo "1. Мониторинг ресурсов в реальном времени"
        echo "2. Мониторинг процессов"
        echo "3. Мониторинг температуры"
        echo "4. Просмотр логов"
        echo "5. Создать отчет о системе"
        echo "6. Рекомендуемый YouTube канал"
        echo "0. Выход"
        
        echo -e "\n${YELLOW}Выберите опцию:${NC}"
        read -r option
        
        case $option in
            1) 
                monitor_resources
                ;;
            2)
                process_monitor
                ;;
            3)
                temperature_monitor
                ;;
            4)
                log_viewer
                ;;
            5)
                create_report
                ;;
            6)
                xdg-open "https://www.youtube.com/@notebook31" 2>/dev/null || \
                echo -e "${YELLOW}Откройте в браузере: https://www.youtube.com/@notebook31${NC}"
                read -n 1 -s -r -p "Нажмите любую клавишу для продолжения..."
                ;;
            0)
                echo -e "${GREEN}Завершение работы...${NC}"
                echo -e "${YELLOW}Не забудьте посетить канал: https://www.youtube.com/@notebook31${NC}"
                exit 0
                ;;
            *)
                echo -e "${RED}Неверная опция.${NC}"
                sleep 1
                ;;
        esac
    done
}

# Инициализация
mkdir -p "$LOG_DIR"
log "Запуск утилиты мониторинга системы"

# Запуск главного меню
main_menu